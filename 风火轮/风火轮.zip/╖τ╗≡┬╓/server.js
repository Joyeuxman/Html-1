const express = require('express')
const app = express()

app.use(express.static('www'))

function getRandom(){
    return Math.floor(Math.random() * 8) + 3
}

app.post('/api/r1', (req, res) => {
    setTimeout(function() {
        res.send('OK')
    }, getRandom() * 1000);
})

app.post('/api/r2', (req, res) => {
    setTimeout(function() {
        res.send('OK')
    }, getRandom() * 1000);
})

app.post('/api/r3', (req, res) => {
    setTimeout(function() {
        res.send('OK')
    }, getRandom() * 1000);
})

app.listen(3000, (req, res) => console.log('正在运行...'))