// new Promise(function(resolve, reject){
//     // 此处省略1万行
//     resolve(1)
// })
// .then(function(value) {
//     alert(value)
//     return A
// })
// .then(function(value) {
//     alert(value)
// }, function(err){
//     alert('Error')
// })
// .catch(function(err){
//     alert(err.message)
// })

$.Deferred(function(d){
    d.resolve(1)
})
.then(function(value){
    alert(value)
    return 2
})
.then(function(value){
    alert(value)
    return 3
})
.done(function(value){
    alert(value)
    return 4
})
.done(function(value){
    alert(value)
    return 5
})