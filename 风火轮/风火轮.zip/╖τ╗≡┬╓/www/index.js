var div = document.querySelector('div')
var img = document.querySelector('img')

function createRequest(name, url, color) {
    // 创建一个处于挂起状态的Deferred对象
    var d = $.Deferred()

    // Deferred对象内部可以没有任务代码，任务代码可以写在
    // Deferred外部，也就是：可以在外部改变Deferred的状态
    var xhr = new XMLHttpRequest()
    xhr.open('POST', url)

    xhr.onload = function () {
        d.resolve({name: name, color: color})
    }

    xhr.onerror = function () {
        d.reject({name: name, color: color})
    }

    xhr.send()
    return d
}

var r1 = createRequest('R1', '/api/r1', 'red')
var r2 = createRequest('R2', '/api/r2', 'yellow')
var r3 = createRequest('R3', '/api/r3', 'blue')

function done(data){
    div.innerHTML = data.name + ' 请求成功！'
    div.style.color = data.color
}

function fail(errorMessage){
    div.innerHTML = errorMessage
    div.style.color = 'black'
}

function progress(value){
    div.innerHTML = value
    div.style.color = 'black'
}

function always(){
    console.log('总是被调用，不管是被resolve，还是reject')
}

r1.done(done).fail(fail).always(always)
r2.done(done).fail(fail).always(always)
r3.done(done).fail(fail).always(always)

// Deferred状态变化之后，不能再次改变状态
// setTimeout(function() {
//     r2.reject('HAHAHAHAHAHEHEHEHEHE')
// }, 15*1000);

var second = 0
var r4 = $.Deferred()

setInterval(function(){
    second++
    r4.notify(second)
    console.log(second)
}, 1000)

// Deferred对象除了具有Promise所具有的3种状态之外
// 还有进度状态。Deferred支持进度，Promise不支持。
// 进度只能在挂起状态时通过notify()改变，如果Deferred被resolve
// 或reject则进度不能再变化
r4.done(done).fail(fail).progress(progress).always(always)


var r = $.when(r1, r2, r3)

r.then(function () {
    setTimeout(function () {
        img.style.display = 'none'
        div.style.color = 'white'
        div.style.fontSize = '36px'
        div.innerHTML = '数据加载完成！'
    }, 1000);

    r4.resolve({name:'Ajax任务完成！', color: 'gold'})

}, function () {
    img.style.display = 'none'
    div.style.color = 'white'
    div.style.fontSize = '36px'
    div.innerHTML = '数据加载出现异常！'
})
